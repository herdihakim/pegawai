<?php
$koneksi=mysql_connect("localhost","root",""); 
$selectdb=mysql_select_db("e-pegawai"); 

date_default_timezone_set("Asia/Jakarta");
?>